import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class blockcop extends HttpServlet { 

public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
          
         response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
         out.println("<html><head>");
	out.println("<link rel=stylesheet href=style3.css>");
	out.println("</head>");
String id = request.getParameter("i");
boolean ret=false;
      try{
        Criminaldao criminal = new Criminaldao(); 
        
	ret=criminal.blockcop(id); 

      if(ret==true){
out.println("<center><h2>COP BLOCKED SUCCESSFULLY</h2></center>");
  
}
      else {
out.println("<center><h2>FAILED TO BLOCK COP</h2></center>");
RequestDispatcher rd=request.getRequestDispatcher("blockcop.jsp");   
	    rd.include(request,response);
}}
     catch(Exception e){
      out.println(e);
    }
	

}
	

}

