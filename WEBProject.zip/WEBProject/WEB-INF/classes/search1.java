


import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class search1 extends HttpServlet { 

public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
	response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
	String name = request.getParameter("c");
      try{
        out.println("<html><head>");
	out.println("<link rel=stylesheet href=style3.css>");
	out.println("</head>");
	
	Criminaldao criminal = new Criminaldao(); 
	Criminal c=criminal.searchcriminal(name); 
 	out.println("<html>"); 
	out.println("<body>"); 
	

	if (c != null){ 
               out.println("<center><h1>Search Results</h1></center>");
		out.println("<center><h3>CRIMINAL ID: " + c.getid() +"</h3></center>" ); 

 		out.println("<center><h3>CRIMINAL NAME: "+ c.getname() +"</h3></center>" ); 

	        out.println("<center><h3>CRIME: "+ c.getcrime() +"</h3></center>" ); 
	
		out.println("<center><h3>ROOM# "+ c.getroomno() +"</h3></center>" ); 

     
		out.println("<center><h3>STATUS "+ c.getstatus() +"</h3></center>" ); 

	

			} 
	else{ 
		out.println("<center><h3>Sorry! No records found</h3></center>" ); 
out.println("<center><h2>TRY AGAIN</h2></center>");
RequestDispatcher rd=request.getRequestDispatcher("searchcrim.jsp");   
	    rd.include(request,response);
	} 
	  out.println("<center><h2>Want to go back?</h2></center>");
	out.println("<form action='btn.jsp' method='POST'>");
   
	out.println("<center><input type= 'submit' value='GO BACK TO ADMIN PAGE' name='XX'  class='s'></center><br><br>");
	out.println("</form>");
	out.println("</body>"); 
	out.println("</html>");
	out.close();
    }
     catch(Exception e){
      out.println(e);
    }
	

}


}






