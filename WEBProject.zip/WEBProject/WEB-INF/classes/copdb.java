import javax.net.ssl.HttpsURLConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class copdb extends HttpServlet {
  public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();


       out.println("<html><head>");
	out.println("<link rel=stylesheet href=style3.css>");
	out.println("</head>");
       HttpSession session = request.getSession(false);
      if(session.getAttribute("check")!="1S" || session.getAttribute("name")==null ){
      response.sendRedirect("logincop.jsp");
  }
     try{   
       Criminaldao cd= new Criminaldao();
        List<cop> cr = new ArrayList<>();
        cr = cd.copdb();
        Iterator<cop> i = cr.iterator();
        out.println("<body>");

        out.println("<table class='new' border=2  color:rgb(146, 187, 233);>");
        out.println("<tr><th>ID</th> <th>Name</th> <th>Rank</th> <th>SPID</th> <th>STATUS</th></tr>");
        while (i.hasNext()) {
           cop c = i.next();
            out.println("<tr><td> " + c.id + "</td> <td>" + c.name + "</td> <td>" + c.rank + "</td>  <td>" + c.spid + "</td> <td> " + c.check + "</td><tr>");
        }



        out.println("</table>");


out.println("<center><h2>GO BACK</h2></center>");
	out.println("<form action='btn.jsp' method='POST'>");
   
	out.println("<center><input type= 'submit' value='GO BACK' name='XX'  class='s'></center><br><br>");
	out.println("</form>");
 out.println("</body></html>");

    }
catch(Exception e){
      out.println(e);
    }

}
}