
import java.io.*;
import java.sql.*;
import java.util.*; 
import javax.servlet.*;
import javax.servlet.http.*; 
public class ControllerServlet extends HttpServlet { 



protected void doGet(HttpServletRequest request, HttpServletResponse response) throws 
ServletException, IOException { 
processRequest(request, response); 
} 


protected void doPost(HttpServletRequest request, HttpServletResponse response) throws 
ServletException, IOException { 
processRequest(request, response); 
} 

protected void processRequest(HttpServletRequest request, 
HttpServletResponse response) throws ServletException, IOException {

String userAction = request.getParameter("action"); 

       
if (userAction.equals("continue") ) { 
response.sendRedirect("signupadmin"); 
}

else if (userAction.equals("login")) { 
response.sendRedirect("logincop.jsp"); 
}
 
else if (userAction.equals("signup")) { 
response.sendRedirect("signupcop.jsp"); 
}

else if (userAction.equals("SEARCH_A_CRIMINAL") ) { 
response.sendRedirect("searchcrim.jsp"); 
}

else if (userAction.equals("SEARCH_A_COP")) { 
response.sendRedirect("searchcop.jsp"); 
}
else if (userAction.equals("ADD_A_COP")) { 
response.sendRedirect("addcop.jsp"); 
}
else if (userAction.equals("ADD_A_CRIMINAL")  ) { 
response.sendRedirect("addcriminal.jsp"); 
}
else if (userAction.equals("DELETE_A_COP")  ) { 
response.sendRedirect("deletecop.jsp"); 
}
else if (userAction.equals("RELEASE_A_CRIMINAL")) { 
response.sendRedirect("releasecriminal.jsp"); 
}
else if (userAction.equals("UPDATE_CRIMINAL_RECORD")) { 
response.sendRedirect("updatecriminal.jsp"); 
}
else if (userAction.equals("UPADATE_COP_RECORD") ) { 
response.sendRedirect("updatecop.jsp"); 
}
else{
response.sendRedirect("trial.html"); 

}
}}