import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;


public class logincop extends HttpServlet { 

public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
	
       response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
       String name = request.getParameter("na");
        String passwd = request.getParameter("pw");
        //HttpSession session = request.getSession();
        //session.setAttribute("name",name);
      
        boolean x=false;
      try{
	Criminaldao criminal = new Criminaldao(); 
	cop co=criminal.logincop(name,passwd); 

        out.println("<html><head>");
	out.println("<link rel=stylesheet href=style1.css>");
	out.println("</head>");

 	out.println("<html>"); 
	out.println("<body>"); 
	String checkk="";
        //out.println("<h1>x</h1>");
       x=criminal.admincheck(name);
       if (co != null){ 
//out.println("<center><h3>STATUS: " + co.getstatus() + "</h3></center>" ); 
                   if(!"blocked".equals(co.getstatus()) ){




                          HttpSession session = request.getSession(true);
                           session.setAttribute("name",co.getname());
                           checkk=co.getspid();
		        if(x==true){
  	        	             session.setAttribute("check","1S");
                 		    }
                      else if(x==false){
  	         		      session.setAttribute("check","0S");
                  		       }
				out.println("<center><h1>Search Results</h1></center>");
				out.println("<center><h3>COP ID: " + co.getid() + "</h3></center>" ); 
		
				out.println("<center><h3>COP NAME: "+ co.getname() + "</h3></center>" ); 
				
			        out.println("<center><h3>RANK: "+ co.getrank() + "</h3></center>" ); 
				
				out.println("<center><h3>SPID: "+ co.getspid() + "</h3></center>" ); 

           		        RequestDispatcher rd=request.getRequestDispatcher("admincheck");   
	                        rd.include(request,response);
         }

                       else if("blocked".equals(co.getstatus()) ){

		out.println("<center><h3>USER IS BLOCKED BY ADMIN :(</h3></center>" );
                     out.println("<form action='logincop.jsp' method='POST'>");
                 	out.println("<center><input type= 'submit' value='LOGIN FROM ANOTHER ACCOUNT' name='action' class='s8'></center><br><br>");
	         out.println("</form>");          

}


}

	else{ 
		out.println("<center><h3>Sorry! No records found</h3></center>" ); 
out.println("<center><h3>TRY AGAIN</h3></center>" ); 
         RequestDispatcher rd=request.getRequestDispatcher("logincop.jsp");   
	      rd.include(request,response); 
	} 


	out.println("</body>"); 
	out.println("</html>");
	out.close();
    }
     catch(Exception e){
      out.println(e);
    }


}
	

}
















