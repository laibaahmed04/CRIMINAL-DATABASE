public class cop{ 
String name; 
String id; 
String rank; 
String spid;
String check;
public cop(String i, String n, String r,String sp,String ch) { 
id = i; 
name = n;
rank = r; 
spid=sp;
check=ch;
} 
public String getid()
	{
		return id;
	}
 
public String getname()
	{
		return name;
	}
public String getrank()
	{
		return rank;
	}
public String getspid()
	{
	return spid;
	}
public String getstatus()
	{
	return check;
	}
}