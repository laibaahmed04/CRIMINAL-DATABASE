
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class admincheck extends HttpServlet { 

public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
	response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
      try{
        out.println("<html><head>");
	out.println("<link rel=stylesheet href=style3.css>");
	out.println("</head>");
     out.println("<body>");
	
	 HttpSession session = request.getSession(false);
	String checkk = (String) session.getAttribute("check");
	// out.println("<h2>"+checkk+"</h2>");
	        //out.println("<h3>"+ session.getAttribute("check")+"</h3>" );
         if(checkk=="1S")
           {
	     
             RequestDispatcher rd=request.getRequestDispatcher("btn.jsp");   
	      rd.include(request,response); 
             
			} 
	   if(checkk=="0S")
           {
	
             RequestDispatcher rd=request.getRequestDispatcher("noadmin.jsp");   
	      rd.include(request,response); 

			}  
	  out.println("<center><h2>Want to go back?</h2></center>");
	out.println("<form action='logincop.jsp' method='POST'>");
   
	out.println("<center><input type= 'submit' value='GO BACK' name='XX'  class='s'></center><br><br>");
	out.println("</form>");
	out.println("</body>"); 
	out.println("</html>");
	out.close();
    }
     catch(Exception e){
      out.println(e);
    }
	

}


}






