import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class addcriminal extends HttpServlet { 

public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
          
         response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
         out.println("<html><head>");
	out.println("<link rel=stylesheet href=style3.css>");
	out.println("</head>");

	String name = request.getParameter("nm");
	String id= request.getParameter("i"); 
	String crime = request.getParameter("cr"); 
	String roomno = request.getParameter("rn");  
	String b = request.getParameter("bl");  
boolean ret=false;
      try{
        Criminaldao criminal = new Criminaldao(); 
        
	ret=criminal.addcriminal(name,id,crime,roomno,b); 

      if(ret==true){
      out.println("<center><h2>CRIMINAL ADDED SUCCESSFULLY</h2></center>");
        Criminal c=criminal.searchcriminal(id); 

		out.println("<center><h3>CRIMINAL ID: " + c.getid() +"</h3></center>" ); 

 		out.println("<center><h3>CRIMINAL NAME: "+ c.getname() +"</h3></center>" ); 

	        out.println("<center><h3>CRIME: "+ c.getcrime() +"</h3></center>" ); 
	
		out.println("<center><h3>ROOM# "+ c.getroomno() +"</h3></center>" ); 
                out.println("<center><h3>STATUS: "+ c.getstatus() + "</h3></center>" );
}
      else {
out.println("<center><h2>FAILED TO ADD A CRIMINAL</h2></center>");
RequestDispatcher rd=request.getRequestDispatcher("addcriminal.jsp");   
	    rd.include(request,response);
}
 
out.println("<center><h2>Want to go back?</h2></center>");
	out.println("<form action='btn.jsp' method='POST'>");
   
	out.println("<center><input type= 'submit' value='GO BACK TO ADMIN PAGE' name='XX'  class='s'></center><br><br>");
	out.println("</form>");
      out.close(); out.println("</html>");
    }
     catch(Exception e){
      out.println(e);
    }
	

}
	

}
