import javax.net.ssl.HttpsURLConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class criminaldb extends HttpServlet {
  public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();


       out.println("<html><head>");
	out.println("<link rel=stylesheet href=style3.css>");
	out.println("</head>");
 HttpSession session = request.getSession(false);
      if(session.getAttribute("check")!="1S" || session.getAttribute("name")==null ){
      response.sendRedirect("logincop.jsp");}
     try{   
       Criminaldao cd= new Criminaldao();
        List<Criminal> cr = new ArrayList<>();
        cr = cd.criminaldb();
        Iterator<Criminal> i = cr.iterator();
        out.println("<body>");

        out.println("<table class='new' border=2  color:rgb(146, 187, 233);>");
        out.println("<tr><th>ID</th> <th>Name</th> <th>Crime</th> <th>Room#</th> <th>STATUS</th> </tr>");
        while (i.hasNext()) {
           Criminal c = i.next();
            out.println("<tr><td> " + c.id + "</td> <td>" + c.name + "</td> <td>" + c.crime + "</td>  <td>" + c.roomid + "</td> <td>" + c.check + "</td><tr>");
        }
        out.println("</table> </body> </html>");
out.println("<center><h2>GO BACK</h2></center>");
	out.println("<form action='btn.jsp' method='POST'>");
   
	out.println("<center><input type= 'submit' value='GO BACK' name='XX'  class='s'></center><br><br>");
	out.println("</form>");
    }
catch(Exception e){
      out.println(e);
    }

}
}