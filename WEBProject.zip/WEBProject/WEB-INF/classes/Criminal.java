public class Criminal{ 
String name; 
String id; 
String crime; 
String roomid;
String check;
public Criminal(String i, String n, String c,String ri,String ch) { 
id = i; 
name = n;
crime = c; 
roomid=ri;
check=ch;
} 
public String getid()
	{
		return id;
	}
 
public String getname()
	{
		return name;
	}
public String getcrime()
	{
		return crime;
	}
public String getroomno()
	{
		return roomid;
	}
public String getstatus()
	{
		return check;
	}
}