import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class signupadmin extends HttpServlet { 

public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
	response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
      try{
out.println("<html><head>");
	out.println("<link rel=stylesheet href=style2.css>");
	out.println("</head>");

        out.println("<html><body>");
	out.println("<h2>Already account?Then login here</h2>");
	out.println("<form action='ControllerServlet' method='POST'>");
        out.println("<center><input type= 'submit' value='login' name='action'  class='s'></center><br><br>");
	out.println("</form>");
	out.println("</body></html>");

        out.println("<html><body>");
	out.println("<h2>NO account?Then SIGNUP here</h2>");
	out.println("<form action='ControllerServlet' method='POST'>");
      
	out.println("<center><input type= 'submit' value='signup' name='action' class='s8'></center><br><br>");
	out.println("</form>");
	out.println("</body></html>");
        
      out.close(); 
    }
     catch(Exception e){
      out.println(e);
    }
	

}
	
 public void doPost(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
    
    	
    }
}
