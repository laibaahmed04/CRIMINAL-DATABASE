import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class logout extends HttpServlet { 

public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
         response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
 out.println("<html><head>");
	out.println("<link rel=stylesheet href=style3.css>");
	out.println("</head>");
       HttpSession session = request.getSession(false);
        session.invalidate();
   
        out.println("<h1>YOU HAVE LOGGED OUT</h2>");

   
out.println("<form action='logincop.jsp' method='POST'>");
          out.println("<center><h1><input type= 'submit' value='LOGIN AGAIN'  class='a1' ></h1></center><br>");
          out.println("</form>");

          
out.println("<form action='signupcop.jsp' method='POST'>");
          out.println("<center><h1><input type= 'submit' value='REGISTER A NEW ACCOUNT'  class='a1' ></h1></center><br>");
          out.println("</form>");

}
	

	

}
