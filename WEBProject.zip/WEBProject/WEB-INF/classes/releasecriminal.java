import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class releasecriminal extends HttpServlet { 

public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
          
         response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
         out.println("<html><head>");
	out.println("<link rel=stylesheet href=style3.css>");
	out.println("</head>");

	String id = request.getParameter("cid");
       boolean ret=false;
      try{
        Criminaldao criminal = new Criminaldao(); 
        
	ret=criminal.releasecriminal(id); 

      if(ret==true){
            out.println("<center><h2>CRIMINAL RELEASED SUCCESSFULLY</h2></center>");
        
}
      else {
	out.println("<center><h2>FAILED TO DELETED A CRIMINAL</h2></center>");
	RequestDispatcher rd=request.getRequestDispatcher("releasecriminal.jsp");   
	    rd.include(request,response);
} out.println("<center><h2>Want to go back?</h2></center>");
	out.println("<form action='btn.jsp' method='POST'>");
   
	out.println("<center><input type= 'submit' value='GO BACK TO ADMIN PAGE' name='XX'  class='s'></center><br><br>");
	out.println("</form>");
      out.close(); out.println("</html>");
    }
     catch(Exception e){
      out.println(e);
    }
	

}
	

}
