import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class updatecop extends HttpServlet { 

public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException { 
          
         response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
         out.println("<html><head>");
	out.println("<link rel=stylesheet href=style3.css>");
	out.println("</head>");

	String id = request.getParameter("i");
	String name = request.getParameter("na"); 
	String rank = request.getParameter("ra"); 
	String spid = request.getParameter("sp");  
	String pw = request.getParameter("pas");

String b = request.getParameter("bl");
boolean ret=false;
      try{
        Criminaldao criminal = new Criminaldao(); 
        
	ret=criminal.updatecop(id,name,rank,spid,pw,b); 

      if(ret==true){
out.println("<center><h2>COP UPDATED SUCCESSFULLY</h2></center>");
   cop c=criminal.searchcop(id); 

   out.println("<body>");
   out.println("<center><h3>COP ID: " + c.getid() + "</h3></center>" ); 

out.println("<center><h3>COP NAME: "+ c.getname() + "</h3></center>" ); 

out.println("<center><h3>RANK: "+ c.getrank() + "</h3></center>" ); 

out.println("<center><h3>SPID: "+ c.getspid() + "</h3></center>" ); 

out.println("<center><h3>SPID: "+ c.getstatus() + "</h3></center>" ); 

}
      else {
out.println("<center><h2>FAILED TO UPDATE A COP</h2></center>");
RequestDispatcher rd=request.getRequestDispatcher("updatecop.jsp");   
	    rd.include(request,response);
}

out.println("<center><h2>Want to go back?</h2></center>");
	out.println("<form action='btn.jsp' method='POST'>");
   
	out.println("<center><input type= 'submit' value='GO BACK TO ADMIN PAGE' name='XX'  class='s'></center><br><br>");
	out.println("</form>");
out.println("</body>"); 
out.println("</html>");
      out.close(); 
    }
     catch(Exception e){
      out.println(e);
    }
	

}
	

}
