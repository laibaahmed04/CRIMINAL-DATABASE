import java.sql.*; 
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*; 
import javax.swing.*;
public class Criminaldao{
	private Connection con; 
        public Statement st;
	public Criminaldao() throws ClassNotFoundException,SQLException{
	establishConnection();
      } 
	private void establishConnection() throws ClassNotFoundException,SQLException{ 
	Class.forName("com.mysql.jdbc.Driver"); 
	String conUrl = "jdbc:mysql://127.0.0.1/criminaldatabase"; 
	con = DriverManager.getConnection(conUrl,"root","root"); 
         st=con.createStatement();
}
     public boolean signupadmin(String id,String name,String rank,String spid,String p,String ch) throws Exception{ 
        boolean flag=false;
        String sql = " INSERT INTO admin VALUES (?, ?, ?, ?, ?, ?)"; 
	PreparedStatement pStmt = con.prepareStatement(sql); 
	pStmt.setString( 1 , id ); 
	pStmt.setString( 2 , name); 
	pStmt.setString( 3 , rank );
	pStmt.setString( 4 , spid);
        pStmt.setString( 5 , p);
        pStmt.setString( 6, ch);
	int rs=pStmt.executeUpdate(); 

     
	if(rs>0)
	{

		flag=true;
	}
	else
	{
		flag=false;
	}
    	 
	return flag; 
	
	}
	


 public Criminal searchcriminal(String id) throws Exception{ 
  Criminal c=null;
  String b="blocked";
	String sql = "SELECT * FROM criminals WHERE criminalid ='"+id+"' and block != '"+b+"'   ";
        ResultSet rs=st.executeQuery(sql); 
       while ( rs.next() ) { 
	String cname= rs.getString(1);
	String cid = rs.getString(2);
	String cri = rs.getString(3);
 	String croom = rs.getString(4);
        String check = rs.getString(5);
	c=new Criminal(cid,cname,cri,croom,check);
	}
return c;

} 
 public cop logincop(String name,String pw) throws Exception{ 
         cop cc=null;


	String sql = "SELECT * FROM admin WHERE name ='"+name+"' and password ='"+pw+"' ";
        ResultSet rs=st.executeQuery(sql); 
       while ( rs.next() ) { 
	String id= rs.getString(1);
	String namec = rs.getString(2);
	String ra = rs.getString(3);
	String sp = rs.getString(4);
        String check1 = rs.getString(6);

	cc=new cop(id,namec,ra,sp,check1);
	
}
return cc;
} 
public boolean admincheck(String name) throws Exception{ 
         boolean flag=false;
	String sql = "SELECT * FROM admin WHERE name ='"+name+"' and Spid ='1S'; ";
        ResultSet rs=st.executeQuery(sql); 
       if ( rs.next() ) { 
                 flag=true;
}       
return flag;
} 

public cop searchcop(String coid) throws Exception{ 
         cop co=null;
 String bc="blocked";
	String sql = "SELECT * FROM admin WHERE ID ='"+coid+"'and blockc != '"+bc+"' ";
	
        ResultSet rs=st.executeQuery(sql); 
       while ( rs.next() ) { 
	String copid= rs.getString(1);
	String copname = rs.getString(2);
	String coprank = rs.getString(3);
	String copspid = rs.getString(4);
       String check2 = rs.getString(6);
	co=new cop(copid,copname,coprank,copspid,check2);
	
}
return co;
} 
public boolean addcop(String id, String cn ,String rnk ,String spd ,String pd ,String b) throws Exception
    {
	 boolean f=false;
     
	
    String sql="INSERT INTO admin(ID,name,Rank,Spid,password,blockc)VALUES('"+ id +"','"+ cn +"','"+ rnk+ "','"+ spd+"','"+ pd +"' ,'"+ b +"')";
	int res = st.executeUpdate(sql);
	
	
	if(res>0)
	{

		f=true;
	}
	else
	{
		f=false;
	}
    	 
	return f; 
	
	}
public boolean addcriminal(String crnm, String crid ,String cr,String rno,String blcr) throws Exception
    {
	 boolean f=false;
     
	
    String sql="INSERT INTO criminals(criminalname,criminalid,crime,roomno,block)VALUES('"+ crnm +"','"+ crid +"','"+ cr+ "','"+ rno+"' ,'"+ blcr +"')";
	int res = st.executeUpdate(sql);
	
	
	if(res>0)
	{

		f=true;
	}
	else
	{
		f=false;
	}
    	 
	return f; 
	
	}

public boolean deletecop(String id) throws Exception
    {
	 boolean flag=false;
     
	String bc="blocked";
     String sql= "delete from admin where (ID ='"+ id +"' and blockc != '"+bc+"' )";
     
	int res = st.executeUpdate(sql);

	if(res>0)
	 {
           flag=true;
       }
	else
	{
		flag=false;
	}
    	 
	return flag; 
	
	}

public boolean releasecriminal(String cid) throws Exception
    {
	 boolean flag=false;
     
	String b="blocked";
     String sql= "delete from criminals where (criminalid ='"+ cid +"' and block != '"+b+"')";
     
	int res = st.executeUpdate(sql);

	if(res>0)
	 {
           flag=true;
       }
	else
	{
		flag=false;
	}
    	 
	return flag; 
	
	}

    public boolean updatecriminal(String crn,String crd,String crm,String ro,String blx) throws Exception
    {
       String b="blocked";
	boolean flag=false;
	String sql="Select * from criminals where (criminalid='"+ crd +"')";
	
        ResultSet res=st.executeQuery(sql); 

    if(res.next())
	{
		String crimname = res.getString("criminalname");
		String crimid = res.getString("criminalid");
		String crimee = res.getString("crime");
		String roomn= res.getString("roomno");
		String sts= res.getString("block");
	    String sql2 = "update criminals set criminalname='" + crn + "',criminalid='" + crd + "',crime='" + crm + "', roomno='" + ro + "' , block='" + blx + "' where (criminalid='"+ crd +"' )";
		int result = st.executeUpdate(sql2);
		if(result>0)
		{
          	  flag=true;
            	   if(crn.isEmpty())
		    {
                    String x1 = "update criminals set criminalname='" + crimname + "' where (criminalid='"+ crd +"')";
		    int r1 = st.executeUpdate(x1);
                   // out.println("<h2>CRIMINAL NAME IS NOT UPDATED</h2>");
		    }
               	 if(crd.isEmpty())
		    {
		    String x2 = "update criminals set criminalid='" + crimid + "' where (criminalid='"+ crd +"')";
		    int r2 = st.executeUpdate(x2);
		  // out.println("<h2>CRIMINAL ID IS NOT UPDATED</h2>");
		    }
		    if(crm.isEmpty())
		    {
		   String x3 = "update criminals set crime='" + crimee + "' where (criminalid='"+ crd +"')";
		    int r3 = st.executeUpdate(x3);
		  // out.println("<h2>CRIME IS NOT UPDATED</h2>");	    
			}
		    if(ro.isEmpty())
		    {
		    String x4 = "update criminals set roomno='" + roomn + "' where (criminalid='"+ crd +"')";
		    int r4 = st.executeUpdate(x4);
		  // out.println("<h2>CRIMINAL ROOM NO IS NOT UPDATED</h2>");
		    }
		  
		   if(blx.isEmpty())
		    {
		    String x5 = "update criminals set block='" + sts + "' where (criminalid='"+ crd +"')";
		    int r5 = st.executeUpdate(x5);
		  // out.println("<h2>CRIMINAL ROOM NO IS NOT UPDATED</h2>");
		    }	
		}
			
	}
	else
	{
		flag=false;
	}
    
	return flag; 
	
}

  public boolean updatecop(String copid,String copname,String coprank,String sspid,String cpwd,String blc) throws Exception
    { String bc="blocked";
       
	boolean flag=false;
	String sql="Select * from admin where (ID='"+ copid +"')";
	
        ResultSet res=st.executeQuery(sql); 

    if(res.next())
	{
		String cpname = res.getString("name");
		String cpmid = res.getString("ID");
		String cprank = res.getString("Rank");
		String cpsid= res.getString("Spid");
 	        String cppwd= res.getString("password");
                String bl= res.getString("blockc");
 	    String sql2 = "update admin set name='" + copname + "',ID='" + copid + "',Rank='" + coprank+ "', Spid='" + sspid + "', password='" + cpwd + "' , blockc='" + blc + "' where (ID='"+ copid +"')";
		int result = st.executeUpdate(sql2);
		if(result>0)
		{
          	  flag=true;
            	   if(copname.isEmpty())
		    {
                    String xc1 = "update admin set name='" + cpname  + "' where (ID='"+ copid +"')";
		    int rc1 = st.executeUpdate(xc1);
                   // out.println("<h2>CRIMINAL NAME IS NOT UPDATED</h2>");
		    }
               	 if(copid.isEmpty())
		    {
		    String xc2 = "update admin set ID='" + cpmid  + "' where (ID='"+ copid +"')";
		    int rc2 = st.executeUpdate(xc2);
		  // out.println("<h2>CRIMINAL ID IS NOT UPDATED</h2>");
		    }
		    if(coprank.isEmpty())
		    {
		   String xc3 = "update admin set Rank='" + cprank + "' where (ID='"+ copid +"')";
		    int rc3 = st.executeUpdate(xc3);
		  // out.println("<h2>CRIME IS NOT UPDATED</h2>");	    
			}
		    if(sspid.isEmpty())
		    {
		    String xc4 ="update admin set Spid='" + cpsid  + "' where (ID='"+ copid +"')";
		    int rc4 =st.executeUpdate(xc4);
		  // out.println("<h2>CRIMINAL ROOM NO IS NOT UPDATED</h2>");
		    }
		  if(cpwd.isEmpty())
		    {
		    String xc5 ="update admin set password='" + cppwd + "' where (ID='"+ copid +"')";
		    int rc5 = st.executeUpdate(xc5);
		  // out.println("<h2>CRIMINAL ROOM NO IS NOT UPDATED</h2>");
		    }
		  
		   	if(blc.isEmpty())
		    {
		    String xc6 ="update admin set blockc='" + bl + "' where (ID='"+ copid +"')";
		    int rc6 = st.executeUpdate(xc6);
		  // out.println("<h2>CRIMINAL ROOM NO IS NOT UPDATED</h2>");
		    }
		}
			
	}
	else
	{
		flag=false;
	}
    
	return flag; 
	
}


public List<Criminal> criminaldb()throws Exception {
		String sql = "select * from criminals ";
		List<Criminal> criminallist = new ArrayList<>();
		
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				String cd= rs.getString("criminalid");
				String crn= rs.getString("criminalname");
				String crm= rs.getString("crime");
				String rn= rs.getString("roomno");
				String b= rs.getString("block");
				Criminal cr = new Criminal(cd, crn ,crm,rn,b);
				criminallist.add(cr);
			}
	
		return criminallist;
	}

public List<cop> copdb()throws Exception {
		String sql = "select * from admin";
		List<cop> coplist = new ArrayList<>();
	
			ResultSet rs =st.executeQuery(sql);
			while (rs.next()) {
				String cpd= rs.getString("ID");
				String cpnm= rs.getString("name");
				String cprnk= rs.getString("Rank");
				String cpsp= rs.getString("Spid");
                                String cpbl= rs.getString("blockc");
				cop cp = new cop(cpd, cpnm ,cprnk,cpsp,cpbl);
				coplist.add(cp);
			}
	
		return coplist;
	}


public boolean blockcriminal(String id) throws Exception{ 
boolean flag=false;

String b="blocked";
	String sql = "SELECT * FROM criminals WHERE criminalid ='"+id+"' and block!= '"+b+"'";
	
        ResultSet rs=st.executeQuery(sql); 
       if ( rs.next() ) { 
                 String up = "update criminals set block='" + b + "' where (criminalid='"+ id +"' and block!= '"+b+"')";
              //pStmt.setString(1, x);
              int rxt = st.executeUpdate(up);
if (rxt > 0){
flag=true;
}}
return flag;
} 

public boolean blockcop(String id) throws Exception{ 
boolean flag=false;
String x="blocked";
	String sql = "SELECT * FROM admin WHERE ID ='"+id+"'  and blockc!= '"+x+"' ";
	
        ResultSet rs=st.executeQuery(sql); 
       if ( rs.next() ) { 
                 String up = "update admin set blockc='" + x + "' where (ID='"+ id +"'   and blockc!= '"+x+"')";
              //pStmt.setString(1, x);
              int rxt = st.executeUpdate(up);
if (rxt > 0){
flag=true;
}}
return flag;
} 




}